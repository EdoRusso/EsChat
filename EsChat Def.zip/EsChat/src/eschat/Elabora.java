/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eschat;

import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.InetAddress;
import java.net.SocketException;
import javax.swing.JOptionPane;

/**
 *
 * @author Edo
 */
public class Elabora {
     public static void elaborazione(CMessaggio messaggio)throws SocketException, IOException {
         CCondivisa c = CCondivisa.getInstance();
        Server s = Server.getInstance();

        if (c.getConnessione() == null) {
            c.setConnessione(new CConnesione());
        }

        String comando = messaggio.getComando();

        if (comando.equals("c") && !c.getConnessione().isApri_connesione()) {
            AccettaConnessione.acceptConnection(messaggio);
        } else if ("c".equals(comando) && c.getConnessione().isApri_connesione()) {
            CMessaggio risposta = new CMessaggio();
            try {
                s.aperturaConnessione(messaggio);
            } catch (IOException ex) {
                Logger.getLogger(Elabora.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Tentativo di connessione con una connessione già avviata con un altro utente,non puoi comunicare");
        } else {
            InetAddress source_address = messaggio.getPacchetto().getAddress();
            if (source_address.equals(c.getRemote_ip())) {
                switch (comando) {
                    case "e":
                        JOptionPane.showMessageDialog(c.getFrame(), "La connessione è stata interrotta da un altro host");
                        c.getConnessione().chiusuraConnessione();
                        break;
                }
            } else {
                if (!messaggio.getComando().equals("e")) {
                    CMessaggio risposta = new CMessaggio();
                    try {
                        s.aperturaConnessione(risposta);
                    } catch (IOException ex) {
                        Logger.getLogger(Elabora.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    System.out.println("Invio messaggio ad un host non connesso");
                }

            }
        }

    }
     

}
